// places
var px = 30
var ex1 = 430
var ey1 = 200
// overig
var nox1 = 0
var inf = 99999999999999999999
var t1 = 10000
var cr1 = 0
var cr2 = 0.05
var bc1 = 25
var bc2 = 0.05
var tg1 = 0

function setup() {
  createCanvas(1100,800)
  rectMode (CENTER)
}

function draw() {
  back()
  player()
  enemy()
  punt()
  timer()
}

function back() {
  // background colour
  background (100,bc1,100)
  bc1 = bc1 + bc2
  if (bc1 >= 200) {
    bc2 = -0.05
  }
  if (bc1 <= 25) {
    bc2 == 0.05
  }
  fill (0)
  // point lines
  stroke (0)
  line (100,0,100,800)
  line (200,0,200,800)
  line (300,0,300,800)
  line (400,0,400,800)
  line (500,0,500,800)
  line (600,0,600,800)
  line (700,0,700,800)
  line (800,0,800,800)
  line (900,0,900,800)
  line (1000,0,1000,800)
  // colour decoration
  noStroke()
  fill (cr1)
  cr1 = cr1 + cr2
  if (cr1 >= 40) {
    cr2 = -0.05
  }
  if (cr1 <= 0) {
    cr2 = 0.05
  }
  // decoration
  rect (1100,0,40,1600)
  rect (550,800,1100,300)
  // rocks
  rect (30,600,180,100)
  rect (200,620,80,80)
  rect (280,580,80,200)
  rect (300,650,200,50)
  rect (480,600,185,120)
  rect (690,650,75,120)
  rect (750,580,95,200)
  rect (1100,600,500,100)
  rect (1100,550,200,80)
}

function player() {
  stroke (0)
  fill (0,255,0)
  rect (px,200,20,20)
}

function enemy() {
  fill (255,0,0)
  ellipse (ex1,ey1,20,20)
}

function mousePressed() {
    px = px + 10
}

function punt() {
  // when you get points 
  if (mouseIsPressed) {
    if (keyIsPressed) {
      if (px == ex1) {
        nox1 = nox1 + 0.5
      }
    }
  }
  // point cube + game timer
  fill (60,120,120)
  rect (nox1,400,30,30)
  ellipse (tg1,350,30,30)
  tg1 = tg1 + 0.2
  if (tg1 >= 1100) {
    ey1 = inf
    px = inf
  }
}

function timer() {
  // when the enemy should move
  ellipse (t1,inf,1,1) 
  t1 = t1 + 1
  if (t1 >= 10600) {
    ex1 = 120
  }
  if (t1 >= 11000) {
    ex1 = 580
  }
  if (t1 >= 11800) {
    ex1 = 1000
  }
  if (t1 >= 12600) {
    ex1 = 240
  }
  if (t1 >= 13500) {
    ex1 = 520
  }
  if (t1 >= 14000) {
    ex1 = 1050
  }
  if (t1 >= 14800) {
    ex1 = 80
  }
  if (t1 >= 15700) {
    ex1 = 920
  }
}

function keyPressed() {
  px = px - 10
}